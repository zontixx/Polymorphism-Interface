package alicemalgulmez_211805078_lab05;

public class Invoice implements Payable {
	private String partNumber;
	private String partDescription;
	private int quantity;
	private double pricePerItem;
	public Invoice(String _partNumber, String _partDescription, int _quantity, double _pricePerItem) {
		partNumber =_partNumber;
		partDescription = _partDescription;
		quantity = _quantity;
		pricePerItem = _pricePerItem;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String _partNumber) {
		partNumber = _partNumber;
	}
	public String getPartDescription() {
		return partDescription;
	}
	public void setPartDescription(String _partDescription) {
		partDescription = _partDescription;
	}
	public int getQuantity() {
		if(quantity>=0) {
			return quantity;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
		
	}
	public void setQuantity(int _quantity) {
		quantity = _quantity;
	}
	public double getPricePerItem() {
		if(pricePerItem>0) {
			return pricePerItem;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
	}
	public void setPricePerItem(double _pricePerItem) {
		pricePerItem = _pricePerItem;
	}
	public double getPaymentAmount() {
		return (getQuantity()*getPricePerItem());
	}
	public String toString() {
		return "invoice: \n" + "part number:" + getPartNumber() + " "+ getPartDescription() +"\n"+
				"quantity: " + getQuantity() + "\n" +
				"price per item: " + getPricePerItem()+ "\n" +
				"payment amount: " + getPaymentAmount() + "\n\n";
	}

}

