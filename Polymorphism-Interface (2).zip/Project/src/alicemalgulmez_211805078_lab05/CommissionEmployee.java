package alicemalgulmez_211805078_lab05;

public class CommissionEmployee extends Employee{
	
	private double grossSales;
	private double commissionRate;
	public CommissionEmployee(String _firstName, String _lastName, String _socialSecurityNumber,double _grossSales, double _commissionRate) {
		super(_firstName, _lastName, _socialSecurityNumber);
		grossSales = _grossSales;
		commissionRate = _commissionRate;
	}
	public double getGrossSales() {
		if(grossSales>=0) {
			return grossSales;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
	}
	public void setGrossSales(double _grossSales) {
		grossSales = _grossSales;
	}
	public double getCommissionRate() {
		if(commissionRate>0 && commissionRate<1) {
			return commissionRate;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
	}
	public void setCommissionRate(double _commissionRate) {
		commissionRate = _commissionRate;
	}

	public double getPaymentAmount() {
		return getCommissionRate()* getGrossSales();
	}
	public String toString() {
		return  "commission employee: " +super.toString() +"\n" +
				"gross sales: $" + getGrossSales() + " " +
				"commission rate: $" + getCommissionRate()+"\n"+
				"payment amount: $" + getPaymentAmount();
	}
	
}

