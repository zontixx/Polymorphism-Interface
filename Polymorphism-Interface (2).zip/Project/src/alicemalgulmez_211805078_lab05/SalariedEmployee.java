package alicemalgulmez_211805078_lab05;

public class SalariedEmployee extends Employee {
	
	private double weeklySalary;
	
	public SalariedEmployee(String _firstName, String _lastName, String _socialSecurityNumber, double _weeklySalary) {
		super(_firstName, _lastName, _socialSecurityNumber);
		weeklySalary = _weeklySalary;
	}

	public double getWeeklySalary() {
		if(weeklySalary>=0) {
			return weeklySalary;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}	}

	public void setWeeklySalary(double _weeklySalary) {
		weeklySalary = _weeklySalary;
	}
	
	public double getPaymentAmount() {
		return getWeeklySalary();
	}
	public String toString() {
		return 	"Salaried employee: " +super.toString() + "\n" + 
				"Weekly salary: $" + getWeeklySalary() + "\n" +
				"Payment amount: $"+getPaymentAmount() + "\n\n";
	}

}
