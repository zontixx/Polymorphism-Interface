package alicemalgulmez_211805078_lab05;

public interface Payable {
	
	double getPaymentAmount();
	
}
