package alicemalgulmez_211805078_lab05;

public abstract class Employee implements Payable{
	private String firstName;
	private String lastName;
	private String socialSecurityNumber;
	public Employee(String _firstName, String _lastName,String _socialSecurityNumber) {
		firstName = _firstName;
		lastName = _lastName;
		socialSecurityNumber = _socialSecurityNumber;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String _firstName) {
		firstName = _firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String _lastName) {
		lastName = _lastName;
	}
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}
	public void setSocialSecurityNumber(String _socialSecurityNumber) {
		socialSecurityNumber = _socialSecurityNumber;
	}
	public String toString() {
		return  getFirstName() + " " + getLastName() + "\n" + "Social security number: " + getSocialSecurityNumber();
	}

}

