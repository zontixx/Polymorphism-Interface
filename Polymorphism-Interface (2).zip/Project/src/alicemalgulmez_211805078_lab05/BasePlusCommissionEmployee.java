package alicemalgulmez_211805078_lab05;

public class BasePlusCommissionEmployee extends CommissionEmployee{

	private double baseSalary;
	public BasePlusCommissionEmployee(	String _firstName, String _lastName, String _socialSecurityNumber,
										double _grossSales, double _commissionRate, double _baseSalary) {
		super(_firstName, _lastName, _socialSecurityNumber, _grossSales, _commissionRate);
		baseSalary = _baseSalary;
	}
	public double getBaseSalary() {
		if(baseSalary>=0) {
			return baseSalary;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
	}

	public void setBaseSalary(double _baseSalary) {
		baseSalary = _baseSalary;
	}
	
	public double getPaymentAmount() {
		return super.getPaymentAmount() + getBaseSalary();
	}
	
	public String toString() {
		return "\n\n" + "base salaried " + super.toString() + " " + "base salary: $" + getBaseSalary();
	}
	
}

