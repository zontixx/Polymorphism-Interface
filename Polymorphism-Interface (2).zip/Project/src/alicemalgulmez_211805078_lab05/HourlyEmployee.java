package alicemalgulmez_211805078_lab05;

public class HourlyEmployee extends Employee {
	
	private double wage;
	private double hours;
	
	public HourlyEmployee(String _firstName, String _lastName, String _socialSecurityNumber,double _wage, double _hours) {
		super(_firstName, _lastName, _socialSecurityNumber);
		wage = _wage;
		hours = _hours;
	}
	public double getWage() {
		if(wage>=0) {
			return wage;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
	}
	public void setWage(double _wage) {
		wage = _wage;
	}
	public double getHours() {
		if(hours>=0 && hours<168) {
			return hours;
		}
		else {
			throw new ArithmeticException("\n You entered an invalid value!! Please enter valid values!!");
		}
	}
	public void setHours(double _hours) {
		hours = _hours;
	}
	@Override
	public double getPaymentAmount() {
		if(hours <= 40) {
			return (wage * hours);
		}
		else {
			return (40 * wage + ((hours-40)*wage*1.5));
		}
	}
	public String toString() {
		return 	"hourly employee: " +super.toString() +"\n" +
				"hourly wage: $" + getWage() + " hours worked: " + getHours()+"\n"+
				"payment amount: $" + getPaymentAmount() + "\n\n";  
	}

}

